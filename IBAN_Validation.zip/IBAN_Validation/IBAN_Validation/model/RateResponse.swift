//
//  RateResponse.swift
//  IBAN_Validation
//
//  Created by Ihab yasser on 21/05/2023.
//

import Foundation
struct RateResponse: Codable {
    let date, historical: String?
    let info: Info?
    let query: Query?
    let result: Double?
    let success: Bool?
}

// MARK: - Info
struct Info: Codable {
    let rate: Double?
    let timestamp: Int?
}

// MARK: - Query
struct Query: Codable {
    let amount: Int?
    let from, to: String?
}
